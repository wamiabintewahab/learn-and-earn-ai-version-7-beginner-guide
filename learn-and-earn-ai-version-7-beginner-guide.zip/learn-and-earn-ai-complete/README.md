# Learn and Earn AI — Version 6

A dark, responsive learning-site starter with learning paths, projects, videos, a browser JavaScript playground, a searchable Learning Library, Settings, Wamia, and a Node.js server. It includes a Render deployment blueprint.

## Run locally

Requirements: Node.js 18 or newer.

1. Extract the ZIP.
2. Open a terminal in `learn-and-earn-ai-complete`.
3. Run `npm start`.
4. Open `http://localhost:3000` (do not open the HTML files directly).

The server creates `server/data/database.json` automatically. It stores accounts and sessions on this server's disk. Passwords are hashed with Node's `scrypt`; the raw password is not saved. Back up the data directory securely and never commit it to Git.

## Accounts and recovery

Signup, login, logout API, sessions, and password reset-token handling are implemented. Password reset works in local development by printing a one-time token to the terminal running the server. Real email delivery is not enabled by default. For a public deployment, configure SMTP variables below and set `RESET_BASE_URL` to the public reset page URL. Do not deploy the development reset-token flow.

Required SMTP environment variables for email delivery:

- `SMTP_HOST`
- `SMTP_PORT` (usually `587`)
- `SMTP_SECURE` (`true` or `false`)
- `SMTP_USER` and `SMTP_PASS` (if required by your SMTP provider)
- `SMTP_FROM`
- `RESET_BASE_URL` (for example `https://your-domain.example/reset-password.html`)

The current local account system does **not** implement email verification, social sign-in, or production-grade abuse protection/rate limiting. Before a public launch, use a maintained authentication provider or complete a security review and add rate limits, CSRF protection, monitoring, backups, and deployment-specific secure-cookie configuration.

## Wamia AI

Wamia has a built-in local helper mode so the chat responds without credentials. It provides basic coding guidance but is **not a generative AI model**. For real conversational AI, configure an OpenAI-compatible chat-completions endpoint using server environment variables:

- `WAMIA_API_KEY` — secret API key (server only)
- `WAMIA_API_URL` — full HTTPS chat-completions endpoint URL
- `WAMIA_MODEL` — provider model name

Set these variables in your hosting provider's server settings, not in HTML, browser JavaScript, or a public Git repository. The provider must accept a JSON body containing `model`, `messages`, and `temperature`, and return `choices[0].message.content`.

## Code playground

The browser playground runs JavaScript in a sandboxed iframe for personal learning. It is not a server-side runtime and does not support Python, Java, or other language execution. Do not accept public untrusted code without a separately isolated execution service with strict CPU, memory, time, and network limits.

## Deployment notes

This project needs a Node.js host for API routes and persistent storage. GitHub Pages is static hosting only; it cannot run `server/server.js`, manage sessions, send reset emails, or proxy Wamia requests. For a public launch, deploy the Node server to a Node-capable host, use HTTPS, configure environment variables, and confirm that persistent disk or an external database is available. This package is a functional starter, not a claim of production certification.


## Version 6 visual and library update

- Colorful dark theme with violet, cyan, mint, and pink accents.
- Searchable Learning Library page at `/library.html`.
- Shared navigation links to the library.
- `render.yaml` describes a Node.js web service deployment and environment-variable prompts.

## Important before public launch

The Render blueprint is a deployment starting point, not a completed hosted deployment. You must create/import the repository in your own hosting account and set secret environment variables privately. A free instance may sleep and does not provide reliable persistent storage for this app's local JSON database; do not use this JSON account store for a real public service. Use a managed database and established auth/OAuth provider before accepting real users. Google sign-in requires creating OAuth credentials and configuring the authorized redirect URI; it is not active just because a Gmail address is entered. Wamia live AI requires a valid provider endpoint/model/key. Multi-language execution requires a separate isolated runner.


## Version 7 beginner guide

- Open `start-here.html` (or click **Start here**) for a Bengali step-by-step navigation guide.
- Use `npm start` and visit `http://localhost:3000`; do not open HTML files directly.
- This package is still a starter, not a production-ready public learning service. Email verification, cross-device progress sync, and secure multi-language execution are not yet complete. Do not accept real public users until these are implemented and tested.
